phi = 3.14

def luas_lingkaran():
  jari = float(input("Masaukkan nilai jari-jari lingkaran: "))
  return phi * jari ** 2

def luas_persegi():
  sisi = float(input("Masukkan nilai sisi persegi: "))
  return sisi ** 2

def luas_persegi_panjang():
  panjang = float(input("Masukkan nilai panjang persegi panjang: "))
  lebar = float(input("Masukkan nilai lebar persegi panjang: "))
  return panjang * lebar
  